package com.example.responsive_sensor_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
