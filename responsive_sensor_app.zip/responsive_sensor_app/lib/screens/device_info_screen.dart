import 'package:flutter/foundation.dart' show kIsWeb, TargetPlatform, defaultTargetPlatform;
import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';

/// Pantalla que muestra la información del dispositivo (hardware, OS, etc.)
/// usando el paquete device_info_plus.
class DeviceInfoScreen extends StatefulWidget {
  const DeviceInfoScreen({super.key});

  @override
  State<DeviceInfoScreen> createState() => _DeviceInfoScreenState();
}

class _DeviceInfoScreenState extends State<DeviceInfoScreen> {
  final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();

  Map<String, String> _info = {};
  String _platformName = '';
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadDeviceInfo();
  }

  Future<void> _loadDeviceInfo() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final Map<String, String> info = {};

      if (kIsWeb) {
        final webInfo = await _deviceInfo.webBrowserInfo;
        _platformName = 'Web';
        info['Navegador'] = webInfo.browserName.name;
        info['User Agent'] = webInfo.userAgent ?? 'N/A';
        info['Idioma'] = webInfo.language ?? 'N/A';
        info['Plataforma'] = webInfo.platform ?? 'N/A';
        info['Producto'] = webInfo.product ?? 'N/A';
        info['Vendor'] = webInfo.vendor ?? 'N/A';
        info['Núcleos lógicos'] =
            webInfo.hardwareConcurrency?.toString() ?? 'N/A';
        info['Max Touch Points'] =
            webInfo.maxTouchPoints?.toString() ?? 'N/A';
      } else {
        switch (defaultTargetPlatform) {
          case TargetPlatform.android:
            final androidInfo = await _deviceInfo.androidInfo;
            _platformName = 'Android';
            info['Marca'] = androidInfo.brand;
            info['Modelo'] = androidInfo.model;
            info['Dispositivo'] = androidInfo.device;
            info['Producto'] = androidInfo.product;
            info['Hardware'] = androidInfo.hardware;
            info['Fabricante'] = androidInfo.manufacturer;
            info['Versión Android'] = androidInfo.version.release;
            info['SDK'] = '${androidInfo.version.sdkInt}';
            info['ID de Build'] = androidInfo.id;
            info['Pantalla'] = androidInfo.display;
            info['Board'] = androidInfo.board;
            info['Fingerprint'] = androidInfo.fingerprint;
            info['Bootloader'] = androidInfo.bootloader;
            info['Host'] = androidInfo.host;
            info['ABIs soportados'] = androidInfo.supportedAbis.join(', ');
            info['Dispositivo físico'] =
                androidInfo.isPhysicalDevice ? 'Sí' : 'No (Emulador)';
          case TargetPlatform.iOS:
            final iosInfo = await _deviceInfo.iosInfo;
            _platformName = 'iOS';
            info['Nombre'] = iosInfo.name;
            info['Modelo'] = iosInfo.model;
            info['Modelo localizado'] = iosInfo.localizedModel;
            info['Versión del sistema'] = iosInfo.systemVersion;
            info['Sistema'] = iosInfo.systemName;
            info['Identificador'] = iosInfo.identifierForVendor ?? 'N/A';
            info['Dispositivo físico'] =
                iosInfo.isPhysicalDevice ? 'Sí' : 'No (Simulador)';
            info['utsname.machine'] = iosInfo.utsname.machine;
            info['utsname.sysname'] = iosInfo.utsname.sysname;
            info['utsname.release'] = iosInfo.utsname.release;
            info['utsname.version'] = iosInfo.utsname.version;
            info['utsname.nodename'] = iosInfo.utsname.nodename;
          case TargetPlatform.windows:
            final windowsInfo = await _deviceInfo.windowsInfo;
            _platformName = 'Windows';
            info['Nombre del equipo'] = windowsInfo.computerName;
            info['Número de procesadores'] = '${windowsInfo.numberOfCores}';
            info['Memoria (MB)'] =
                '${windowsInfo.systemMemoryInMegabytes}';
            info['Nombre de usuario'] = windowsInfo.userName;
            info['Versión del sistema'] =
                '${windowsInfo.majorVersion}.${windowsInfo.minorVersion}';
            info['Build Number'] = '${windowsInfo.buildNumber}';
            info['Edición registrada'] = windowsInfo.registeredOwner;
            info['ID del producto'] = windowsInfo.productId;
            info['Nombre del producto'] = windowsInfo.productName;
            info['ID del dispositivo'] = windowsInfo.deviceId;
          case TargetPlatform.linux:
            final linuxInfo = await _deviceInfo.linuxInfo;
            _platformName = 'Linux';
            info['Nombre'] = linuxInfo.name;
            info['Versión'] = linuxInfo.version ?? 'N/A';
            info['ID'] = linuxInfo.id;
            info['Pretty Name'] = linuxInfo.prettyName;
            info['Build ID'] = linuxInfo.buildId ?? 'N/A';
            info['Variant'] = linuxInfo.variant ?? 'N/A';
            info['Variant ID'] = linuxInfo.variantId ?? 'N/A';
            info['Machine ID'] = linuxInfo.machineId ?? 'N/A';
          case TargetPlatform.macOS:
            final macInfo = await _deviceInfo.macOsInfo;
            _platformName = 'macOS';
            info['Nombre del equipo'] = macInfo.computerName;
            info['Nombre del host'] = macInfo.hostName;
            info['Modelo'] = macInfo.model;
            info['Arch'] = macInfo.arch;
            info['Versión del kernel'] = macInfo.kernelVersion;
            info['OS Release'] = macInfo.osRelease;
            info['CPU activos'] = '${macInfo.activeCPUs}';
            info['Memoria (MB)'] =
                '${(macInfo.memorySize / (1024 * 1024)).round()}';
            info['CPU Frequency (MHz)'] = '${macInfo.cpuFrequency}';
          case TargetPlatform.fuchsia:
            _platformName = 'Fuchsia';
            info['Info'] = 'Plataforma no soportada en detalle';
        }
      }

      if (mounted) {
        setState(() {
          _info = info;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return SafeArea(
      child: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _buildError(context)
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ── Header ──
                      Row(
                        children: [
                          Icon(Icons.phone_android,
                              color: colorScheme.primary, size: 28),
                          const SizedBox(width: 12),
                          Text(
                            'Info del Dispositivo',
                            style: theme.textTheme.headlineMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const Spacer(),
                          IconButton.filled(
                            onPressed: _loadDeviceInfo,
                            icon: const Icon(Icons.refresh),
                            tooltip: 'Actualizar',
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Datos del hardware y sistema operativo.',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 24),

                      // ── Platform badge ──
                      Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 24, vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                colorScheme.primary,
                                colorScheme.tertiary,
                              ],
                            ),
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(_platformIcon(),
                                  color: Colors.white, size: 22),
                              const SizedBox(width: 10),
                              Text(
                                _platformName,
                                style: theme.textTheme.titleMedium?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),

                      // ── Info list ──
                      Card(
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                          side: BorderSide(color: colorScheme.outlineVariant),
                        ),
                        child: Column(
                          children: _info.entries.map((entry) {
                            final index =
                                _info.keys.toList().indexOf(entry.key);
                            final isLast = index == _info.length - 1;
                            return Column(
                              children: [
                                _InfoTile(
                                  label: entry.key,
                                  value: entry.value,
                                ),
                                if (!isLast)
                                  Divider(
                                    height: 1,
                                    indent: 20,
                                    endIndent: 20,
                                    color: colorScheme.outlineVariant
                                        .withAlpha(80),
                                  ),
                              ],
                            );
                          }).toList(),
                        ),
                      ),

                      const SizedBox(height: 16),

                      // ── Paquete usado ──
                      Card(
                        color: colorScheme.secondaryContainer,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Row(
                            children: [
                              Icon(Icons.extension,
                                  color: colorScheme.onSecondaryContainer),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  'Datos obtenidos con device_info_plus',
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    color: colorScheme.onSecondaryContainer,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  Widget _buildError(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Card(
          color: Colors.red.withAlpha(20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: Colors.red.withAlpha(60)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, color: Colors.red, size: 48),
                const SizedBox(height: 16),
                Text(
                  'Error al obtener info del dispositivo',
                  style: Theme.of(context).textTheme.titleMedium,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  _error!,
                  style: Theme.of(context).textTheme.bodySmall,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: _loadDeviceInfo,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Reintentar'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  IconData _platformIcon() {
    if (_platformName == 'Android') return Icons.android;
    if (_platformName == 'iOS') return Icons.apple;
    if (_platformName == 'Windows') return Icons.desktop_windows;
    if (_platformName == 'macOS') return Icons.laptop_mac;
    if (_platformName == 'Linux') return Icons.computer;
    if (_platformName == 'Web') return Icons.language;
    return Icons.device_unknown;
  }
}

/// Tile con label y valor para la lista de info.
class _InfoTile extends StatelessWidget {
  final String label;
  final String value;

  const _InfoTile({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: colorScheme.onSurfaceVariant,
                    fontWeight: FontWeight.w500,
                  ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            flex: 3,
            child: Text(
              value,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
              textAlign: TextAlign.end,
            ),
          ),
        ],
      ),
    );
  }
}
