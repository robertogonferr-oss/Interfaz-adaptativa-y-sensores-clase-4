import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'battery_screen.dart';
import 'device_info_screen.dart';

/// Shell responsivo que usa LayoutBuilder para decidir entre
/// NavigationBar (pantalla angosta) y NavigationRail (pantalla ancha).
class ResponsiveShell extends StatefulWidget {
  const ResponsiveShell({super.key});

  @override
  State<ResponsiveShell> createState() => _ResponsiveShellState();
}

class _ResponsiveShellState extends State<ResponsiveShell> {
  int _selectedIndex = 0;

  static const List<Widget> _screens = [
    HomeScreen(),
    BatteryScreen(),
    DeviceInfoScreen(),
  ];

  static const List<NavigationDestination> _navDestinations = [
    NavigationDestination(
      icon: Icon(Icons.home_outlined),
      selectedIcon: Icon(Icons.home),
      label: 'Inicio',
    ),
    NavigationDestination(
      icon: Icon(Icons.battery_std_outlined),
      selectedIcon: Icon(Icons.battery_std),
      label: 'Batería',
    ),
    NavigationDestination(
      icon: Icon(Icons.phone_android_outlined),
      selectedIcon: Icon(Icons.phone_android),
      label: 'Dispositivo',
    ),
  ];

  static const List<NavigationRailDestination> _railDestinations = [
    NavigationRailDestination(
      icon: Icon(Icons.home_outlined),
      selectedIcon: Icon(Icons.home),
      label: Text('Inicio'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.battery_std_outlined),
      selectedIcon: Icon(Icons.battery_std),
      label: Text('Batería'),
    ),
    NavigationRailDestination(
      icon: Icon(Icons.phone_android_outlined),
      selectedIcon: Icon(Icons.phone_android),
      label: Text('Dispositivo'),
    ),
  ];

  /// Umbral de ancho para cambiar de NavigationBar a NavigationRail.
  static const double _breakpoint = 600;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final bool isWide = constraints.maxWidth >= _breakpoint;

        if (isWide) {
          // ── Pantalla ancha → NavigationRail al costado ──
          return Scaffold(
            body: Row(
              children: [
                NavigationRail(
                  selectedIndex: _selectedIndex,
                  onDestinationSelected: _onDestinationSelected,
                  labelType: NavigationRailLabelType.all,
                  leading: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: Icon(
                      Icons.sensors,
                      size: 32,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  destinations: _railDestinations,
                ),
                const VerticalDivider(thickness: 1, width: 1),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    child: _screens[_selectedIndex],
                  ),
                ),
              ],
            ),
          );
        } else {
          // ── Pantalla angosta → NavigationBar abajo ──
          return Scaffold(
            body: AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: _screens[_selectedIndex],
            ),
            bottomNavigationBar: NavigationBar(
              selectedIndex: _selectedIndex,
              onDestinationSelected: _onDestinationSelected,
              animationDuration: const Duration(milliseconds: 400),
              destinations: _navDestinations,
            ),
          );
        }
      },
    );
  }

  void _onDestinationSelected(int index) {
    setState(() => _selectedIndex = index);
  }
}
