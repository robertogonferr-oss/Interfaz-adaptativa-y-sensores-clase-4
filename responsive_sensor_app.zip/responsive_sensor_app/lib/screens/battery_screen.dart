import 'dart:async';
import 'package:flutter/material.dart';
import 'package:battery_plus/battery_plus.dart';

/// Pantalla que muestra la información de batería en tiempo real
/// usando el paquete battery_plus.
class BatteryScreen extends StatefulWidget {
  const BatteryScreen({super.key});

  @override
  State<BatteryScreen> createState() => _BatteryScreenState();
}

class _BatteryScreenState extends State<BatteryScreen>
    with SingleTickerProviderStateMixin {
  final Battery _battery = Battery();

  int _batteryLevel = -1;
  BatteryState _batteryState = BatteryState.unknown;
  bool _isLoading = true;
  String? _error;

  StreamSubscription<BatteryState>? _batteryStateSubscription;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _loadBatteryInfo();
  }

  Future<void> _loadBatteryInfo() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final level = await _battery.batteryLevel;
      final state = await _battery.batteryState;

      // Escuchar cambios de estado de la batería
      _batteryStateSubscription?.cancel();
      _batteryStateSubscription =
          _battery.onBatteryStateChanged.listen((newState) {
        if (mounted) {
          setState(() => _batteryState = newState);
          // Actualizar nivel también cuando cambia el estado
          _battery.batteryLevel.then((lvl) {
            if (mounted) setState(() => _batteryLevel = lvl);
          });
        }
      });

      if (mounted) {
        setState(() {
          _batteryLevel = level;
          _batteryState = state;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _batteryStateSubscription?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header ──
            Row(
              children: [
                Icon(Icons.battery_std, color: colorScheme.primary, size: 28),
                const SizedBox(width: 12),
                Text(
                  'Batería',
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                IconButton.filled(
                  onPressed: _loadBatteryInfo,
                  icon: const Icon(Icons.refresh),
                  tooltip: 'Actualizar',
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Información en tiempo real de la batería del dispositivo.',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 32),

            if (_isLoading)
              const Center(
                child: Padding(
                  padding: EdgeInsets.all(48),
                  child: CircularProgressIndicator(),
                ),
              )
            else if (_error != null)
              _ErrorCard(error: _error!)
            else ...[
              // ── Battery gauge ──
              Center(
                child: ScaleTransition(
                  scale: _pulseAnimation,
                  child: _BatteryGauge(
                    level: _batteryLevel,
                    state: _batteryState,
                  ),
                ),
              ),
              const SizedBox(height: 32),

              // ── Detail cards ──
              LayoutBuilder(
                builder: (context, constraints) {
                  final isWide = constraints.maxWidth > 500;
                  final cards = [
                    _DetailCard(
                      icon: Icons.battery_full,
                      label: 'Nivel',
                      value: '$_batteryLevel%',
                      color: _levelColor(_batteryLevel),
                    ),
                    _DetailCard(
                      icon: _stateIcon(_batteryState),
                      label: 'Estado',
                      value: _stateLabel(_batteryState),
                      color: _stateColor(_batteryState),
                    ),
                  ];

                  if (isWide) {
                    return Row(
                      children: cards
                          .map((c) => Expanded(
                                child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 6),
                                  child: c,
                                ),
                              ))
                          .toList(),
                    );
                  }
                  return Column(
                    children: cards
                        .map((c) =>
                            Padding(padding: const EdgeInsets.only(bottom: 12), child: c))
                        .toList(),
                  );
                },
              ),
              const SizedBox(height: 16),
              _SaveBatteryTipsCard(
                batteryState: _batteryState,
                level: _batteryLevel,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Color _levelColor(int level) {
    if (level > 60) return Colors.green;
    if (level > 20) return Colors.orange;
    return Colors.red;
  }

  IconData _stateIcon(BatteryState state) {
    switch (state) {
      case BatteryState.charging:
        return Icons.battery_charging_full;
      case BatteryState.discharging:
        return Icons.battery_alert;
      case BatteryState.full:
        return Icons.battery_full;
      case BatteryState.connectedNotCharging:
        return Icons.power;
      case BatteryState.unknown:
        return Icons.battery_unknown;
    }
  }

  String _stateLabel(BatteryState state) {
    switch (state) {
      case BatteryState.charging:
        return 'Cargando';
      case BatteryState.discharging:
        return 'Descargando';
      case BatteryState.full:
        return 'Completa';
      case BatteryState.connectedNotCharging:
        return 'Conectado (sin cargar)';
      case BatteryState.unknown:
        return 'Desconocido';
    }
  }

  Color _stateColor(BatteryState state) {
    switch (state) {
      case BatteryState.charging:
        return Colors.blue;
      case BatteryState.full:
        return Colors.green;
      case BatteryState.discharging:
        return Colors.orange;
      case BatteryState.connectedNotCharging:
        return Colors.teal;
      case BatteryState.unknown:
        return Colors.grey;
    }
  }
}

/// Gauge visual circular de batería.
class _BatteryGauge extends StatelessWidget {
  final int level;
  final BatteryState state;

  const _BatteryGauge({required this.level, required this.state});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final Color gaugeColor;
    if (level > 60) {
      gaugeColor = Colors.green;
    } else if (level > 20) {
      gaugeColor = Colors.orange;
    } else {
      gaugeColor = Colors.red;
    }

    return SizedBox(
      width: 200,
      height: 200,
      child: Stack(
        alignment: Alignment.center,
        children: [
          SizedBox(
            width: 200,
            height: 200,
            child: CircularProgressIndicator(
              value: level / 100,
              strokeWidth: 14,
              strokeCap: StrokeCap.round,
              backgroundColor: colorScheme.surfaceContainerHighest,
              valueColor: AlwaysStoppedAnimation<Color>(gaugeColor),
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                state == BatteryState.charging
                    ? Icons.bolt
                    : Icons.battery_std,
                size: 36,
                color: gaugeColor,
              ),
              const SizedBox(height: 4),
              Text(
                '$level%',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: gaugeColor,
                    ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Tarjeta de detalle individual.
class _DetailCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _DetailCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: colorScheme.outlineVariant),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withAlpha(30),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 28),
            ),
            const SizedBox(width: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: colorScheme.onSurfaceVariant,
                      ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Tarjeta con consejos para ahorrar batería.
class _SaveBatteryTipsCard extends StatelessWidget {
  final BatteryState batteryState;
  final int level;

  const _SaveBatteryTipsCard({
    required this.batteryState,
    required this.level,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    String tip;
    IconData tipIcon;
    Color tipColor;

    if (batteryState == BatteryState.charging) {
      tip = '⚡ La batería se está cargando. Evita usar el dispositivo '
          'mientras carga para prolongar la vida útil.';
      tipIcon = Icons.tips_and_updates;
      tipColor = Colors.blue;
    } else if (level <= 20) {
      tip = '🔴 Batería baja. Conecta el cargador pronto o activa '
          'el modo de ahorro de energía.';
      tipIcon = Icons.warning_amber;
      tipColor = Colors.red;
    } else if (level <= 50) {
      tip = '🟡 Batería moderada. Reduce el brillo de pantalla y cierra '
          'apps en segundo plano para mayor duración.';
      tipIcon = Icons.lightbulb_outline;
      tipColor = Colors.orange;
    } else {
      tip = '🟢 Batería en buen nivel. Tu dispositivo tiene suficiente '
          'energía para un uso prolongado.';
      tipIcon = Icons.check_circle_outline;
      tipColor = Colors.green;
    }

    return Card(
      color: tipColor.withAlpha(20),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: tipColor.withAlpha(60)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(tipIcon, color: tipColor, size: 24),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                tip,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: colorScheme.onSurface,
                    ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Tarjeta de error.
class _ErrorCard extends StatelessWidget {
  final String error;
  const _ErrorCard({required this.error});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.red.withAlpha(20),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: Colors.red.withAlpha(60)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            const Icon(Icons.error_outline, color: Colors.red, size: 28),
            const SizedBox(width: 14),
            Expanded(
              child: Text(
                'Error al obtener datos de batería:\n$error',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
